# Agile-Project

SPORK Recipes
“All the dish recipes you will ever need, to enjoy with spoon, fork or both”


run the following command
pip install -r requirements.txt


This a development branch where we test and combine all the work.


